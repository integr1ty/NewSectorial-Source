<?php
include('webconfigs/config.php');
include('webconfigs/head.php');
?>

<!DOCTYPE html>
  <head>
    <title>Error 404 - <?php echo $sitename; ?></title>
  </head>

 <div class="main-holder grid">
<div style="text-align:center;padding-top:0px;">
<span style="font-weight:600;font-size:3rem;display:block;">Error 404</span>
  <?php
        $users = array(2,111,49,56);
        shuffle($users);
        foreach($users as $u) {
          echo '<img style="height: 250px;" src="/avatar/render/avatars/'.$u.'.png">';
        }
        ?>
</div>
</div>
   