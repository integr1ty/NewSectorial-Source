     <link rel="stylesheet" href="style.css">

<h2>ROBLOX Hat</h2>
                        <div id="Item">
                            <div id="Thumbnail">
                                <a id="ctl00_cphRoblox_AssetThumbnailImage" title="ROBLOX Visor" onclick="javascript:__doPostBack('ctl00$cphRoblox$AssetThumbnailImage','')" style="display:inline-block;cursor:pointer;">
                                    <img src="https://web.archive.org/web/20080101012103im_/http://t1.roblox.com:80/Hat-250x250-a1dbc63515f5516ad05a954df6cb6871.Png" border="0" id="img" alt="ROBLOX Visor" blankurl="http://t6.roblox.com:80/blank-250x250.gif"/>
                                </a>
                            </div>
                            <div id="Summary">
                                <h3>ROBLOX Visor</h3>
                                <div id="ctl00_cphRoblox_TicketsPurchasePanel">
                                    <div id="TicketsPurchase">
                                        <div id="PriceInTickets">Tx: 8</div>
                                        <div id="BuyWithTickets">
                                            <a id="ctl00_cphRoblox_PurchaseWithTicketsButton" class="Button" href="javascript:__doPostBack('ctl00$cphRoblox$PurchaseWithTicketsButton','')">Buy with Tx</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="Creator">
                                    Created by: <a id="ctl00_cphRoblox_CreatorHyperLink" href="User.aspx?ID=1">ROBLOX</a>
                                </div>
                                <div id="LastUpdate">Updated: 2 months ago</div>
                                <div id="ctl00_cphRoblox_DescriptionPanel">
                                    <div id="DescriptionLabel">Description:</div>
                                    <div id="Description">Keep cool under this ROBLOX visor.</div>
                                </div>
                                <p>
                                <div id="ctl00_cphRoblox_AbuseReportButton1_AbuseReportPanel" class="ReportAbusePanel">
                                    <span class="AbuseIcon">
                                        <a id="ctl00_cphRoblox_AbuseReportButton1_ReportAbuseIconHyperLink" href="AbuseReport/AssetVersion.aspx?ID=163920&amp;ReturnUrl=http%3a%2f%2fwww.roblox.com%2fItem.aspx%3fID%3d1163672">
                                            <img src="/web/20080101012103im_/http://www.roblox.com/images/abuse.PNG" alt="Report Abuse" border="0"/>
                                        </a>
                                    </span>
                                    <span class="AbuseButton">
                                        <a id="ctl00_cphRoblox_AbuseReportButton1_ReportAbuseTextHyperLink" href="AbuseReport/AssetVersion.aspx?ID=163920&amp;ReturnUrl=http%3a%2f%2fwww.roblox.com%2fItem.aspx%3fID%3d1163672">Report Abuse</a>
                                    </span>
                                </div>