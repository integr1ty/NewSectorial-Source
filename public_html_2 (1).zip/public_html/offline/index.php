<?php
  include("../webconfigs/configuration.php");

$error = array();
  
   
  
    $key = "Sectori@lDevKey!20";
    if(!empty($_POST)){
        if($_POST["key"] != $key){
            $error[] = "<p style='color:#FF0000;'> sorry thats the wrong key lol</p>";
        }
     
        
        if(empty($error)){
            $_SESSION['canAccess']="true";
      header("Location: /");
        }
    }
  
  
$econSQL = "SELECT SUM(`bits`) AS 'totalBits' FROM `beta_users`";
$econQ = $conn->query($econSQL);
$econRow = $econQ->fetch_assoc();
$totalBits = $econRow['totalBits'];

$econT = $totalBits;
  

$econSQL = "SELECT SUM(`bucks`) AS 'totalBucks' FROM `beta_users`";
$econQ = $conn->query($econSQL);
$econRow = $econQ->fetch_assoc();
$totalBucks = $econRow['totalBucks'];

$econR = $totalBucks;
  
   $result = mysqli_query($conn, "SELECT username FROM beta_users ORDER BY id");

$row_cnt = mysqli_num_rows($result);
    $result = mysqli_query($conn, "SELECT name FROM shop_items ORDER BY id");

$row_int = mysqli_num_rows($result);
     $result = mysqli_query($conn, "SELECT id FROM moderation ORDER BY id");

$row_bnt = mysqli_num_rows($result);
   $result = mysqli_query($conn, "SELECT name FROM clans ORDER BY id");

$row_gnt = mysqli_num_rows($result);

 
?>
<head>
      <link rel="shortcut icon" href="/SectLogo.png">
    <link rel="stylesheet" href="/sectomain.css" type="text/css">

<link rel="stylesheet" href="https://web.archive.org/web/20220511174814cs_/https://pro.fontawesome.com/releases/v5.15.3/css/all.css">
<link rel="stylesheet" href="https://web.archive.org/web/20220511174814cs_/https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&amp;display=swap">

<link rel="stylesheet" href="https://web.archive.org/web/20220511174814cs_/https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.css">
<link rel="stylesheet" href="https://web.archive.org/web/20220511174814cs_/https://www.uxhill.com/css/themes/light.css?v=1383674858">
<link rel="stylesheet" href="https://web.archive.org/web/20220511174814cs_/https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <body style="background-color:#f0a908;">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Maintenance - Sectorial</title>

</head>
<body style="background: #f0a908;">
  
     <div class="header"></div>
  <br><br>
    <div class="containergrey_nopadding">
  <h4 class="banner_title">
Sectorial Developer Key</h4>
      <br>
<form method="POST" action="#">
<?php
echo'<input type="password" class="input" name="key" placeholder="Developer Key" type="text">';
echo'';
 echo'
<button class="BigButton g-recaptcha">Enter</button>';
?>
  
</form>
      Our web developers are working hard fix everything!<br><i style="color:#aaa;">*We should be back up soon so no need to keep checking in.*</i>
     <?php if($error != null){ ?>

 <?=$error[0]?>
   
<?php } ?>
<script>
// Set the date we're counting down to
var countDownDate = new Date("Jun 15, 2023 1:37:25").getTime();

var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    var distance = countDownDate - now;
    
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById("timer").innerHTML = days + "d " + hours + "h "
    + minutes + "m " + seconds + "s ";
    
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("timer").innerHTML = "<p style='font-weight:bold;color:#1fc111;'>Site will be up shortly.</p>";
    }
}, 1000);
</script>
  </div><br><br>
  
<div class="catalogcontainer">
    <h2><?php echo $sitename; ?> is undergoing maintenance.</h2>
    <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Finished</h4>
      <ul>
        <div class="nav">
                  <li>Landing Page</li>
          
        <li>Login System</li>
           <li>Registration System</li>
    <li>Dashboard</li>
     <li>Settings</li>
          <li>People</li>
          <li>Profiles</li>
          <li>Avatar Rendering</li>
          <li>Catalog</li>
          <li>Clothing Rendering</li>
    <li>Builders Club</li>
           <li>Groups</li>
          <li>Friends</li>
          <li>Messaging System</li>
          <li>Promocodes</li>
          <br>
      </div></ul>
    </div>
    <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Working on</h4>
      <ul>
        <div class="nav">
        <li>Trading System</li>
        <li>Games System</li>
          <li>Forums</li>
          <li>Leaderboards</li>
          <br>
      </div></ul>
    </div>
    <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Future Release</h4>
      <ul>
        <div class="nav">
        <li>Client</li>
                  <li>Servers</li>
          <li>Workshop</li>
          <br>
      </div></ul>
    </div>
    
  <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Site Statistics</h4>
      <ul>
        <div class="nav">
        <li>Users: (<?php echo $row_cnt; ?>)</li>
                  <li>Items: (<?php echo $row_int; ?>)</li>
          <li>Groups: (<?php echo $row_gnt; ?>)</li>
         <li>Banned: (<?php echo $row_int; ?>)</li>
                   <li>Forums: (0)</li>
       <li> <img style="width:25px;vertical-align: middle;" src="/tixicon.png">: (<?php echo $econT; ?>)</li>
                 <li>&nbsp;<img style="width:18px;vertical-align: middle;" src="/robux_icon.png">: (<?php echo $econR; ?>)</li>
          <br>
      </div></ul>
    </div>
  
   <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Socials</h4>
      <ul>
        <div class="nav">
        <li><a href="https://discord.gg/Uy4hxYEKFK">Discord</a></li>
     <li><a href="https://twitter.com/vetatoriumm">Twitter</a></li>
        <li><a href="#">Reddit</a></li>
      <li><a href="#">Youtube</a></li>
          <br>
      </div></ul>
    </div>
    
  
    
  
</div>

  
 

  