<?php
  include("../webconfigs/config.php");
  include("../webconfigs/head.php");
  
  if(!$loggedIn) {header('Location: ../'); die();}
  
?>
<!DOCTYPE>
<html>

  <head>
    <title>Games - <?php echo $sitename; ?></title>
  </head>
 
<div class="catalogcontainer"><br><br>
  <center>There are no active servers currently. We are still developing our client!</center>
  </div>