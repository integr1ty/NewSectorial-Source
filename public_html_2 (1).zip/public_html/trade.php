<?php
  include('webconfigs/config.php');
  include('webconfigs/header.php');
?>
<!DOCTYPE html>
  <head>
    <title>Trade - Sectorial</title>
  </head>
  <body>
    <div id="body">
      <div id="box">
      <div id="crate"></div>
      </div>
    </div>
    <script>
      window.onload = function() {
        getPage(1);
      };
      
      function getPage(page) {
        $("#crate").load("trade_crate.php?id="+<?php echo $id; ?>+"&type="+type+"&page="+page);
      };
    </script>
  </body>
</html>