<?php
  include("../webconfigs/config.php");
  include("../webconfigs/header.php");
  
  
  if(isset($_GET['search'])) {
    $searchQ = htmlentities($_GET['search']);
  } else {
    $searchQ = '';
  }
?>

<!DOCTYPE html>
  <head>
    <title>Shop - <?php echo $sitename; ?></title>
  </head>
  <body>
<?php
include('shopheader.php');
?>
    
<div id="box" style="margin-top:10px;padding-left: 20px;padding-top: 10px; width:95.5%; margin-left:13px;">
        <div id="crate"></div>
      </div>
<script>
    $(window).scroll(debouncer(function() {
        if($(window).scrollTop() + $(window).height() >= $(document).height() - 100 && !shopEnd) {
            loadItems($('.shop-categories .active a').data('itemType'), $('#shopSort :selected').data('sort'), currentSearch, shopPage + 1)
        }
    }));

    loadItems()
</script>

    
<script>
  
  window.onload = function() {
      getPage('hat','',0);
    };
  
    function getPage(type, search, page) {
      $("#crate").load("/shop/crate?item="+type+"&search="+search+"&page="+page);
    };
</script>
    </div>
   
  </body>
<html>