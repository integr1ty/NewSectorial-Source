<?php
session_name("BRICK-SESSION");
session_start();
include("../webconfigs/config.php");
if(isset($_GET['page'])) {
  $page = mysqli_real_escape_string($conn,$_GET['page']);
  $page = max($page,0);

  $limit = ($page)*36;
  if(isset($_GET['item']) || isset($_GET['search'])) {
    $crateSQL = "SELECT * FROM `shop_items` WHERE ";
    if(isset($_GET['item'])) {
      $item = mysqli_real_escape_string($conn,$_GET['item']);
      if($item == 'all') {
        $crateSQL = $crateSQL."`approved`='yes' AND `type`='hat' OR `type`='tool' OR `type`='face' OR `type`='tshirt' OR `type` = 'shirt' OR `type`='pants' OR `type`='head' AND";
      } else {
        $crateSQL = $crateSQL."`approved`='yes' AND `type`='$item' AND";
      }
    } else {$item = '';}
    if(isset($_GET['search'])) {
      $search = mysqli_real_escape_string($conn,$_GET['search']);
      $crateSQL = $crateSQL."`name` LIKE '%$search%' AND ";
    } else {$search = '';}
    $countSQL = $crateSQL."`approved`='yes'";
    $crateSQL = $crateSQL."`approved`='yes' ORDER BY `last_updated` DESC LIMIT $limit,40";
  } else {
    $crateSQL = "SELECT * FROM `shop_items` WHERE `type`='hat' OR `type`='tool' OR `type`='face' ORDER BY `last_updated` DESC LIMIT $limit,40";
    $countSQL = "SELECT * FROM `shop_items` WHERE `approved`='yes' AND (`type`='hat' OR `type`='tool' OR `type`='face')";
  }
  
  $result = $conn->query($crateSQL);
  $count = $conn->query($countSQL);
  $items = $count->num_rows;
  if ($items < 1) { echo '<div style="text-align: center;">No results found!</div>'; die();}
  $r = 0;
  echo '<div style="width:100%;display:block;overflow:auto;">';
  while($searchRow=$result->fetch_assoc()){
    $r++;
    //if($r >= (($page+1)*36)) {break;}
    //if($r >= ($page*36)) {
      $id = $searchRow['owner_id'];
      $sqlUser = "SELECT * FROM `beta_users` WHERE  `id` = '$id'";
      $userResult = $conn->query($sqlUser);
      $userRow=$userResult->fetch_assoc();
    
      echo '<div style="margin: 10px; width: 142px; display:inline-block; ';
      echo'">';
      
      // If collectible
     
      
      if ($searchRow['approved'] == 'yes') {$thumbnail = $searchRow['id'];}
      elseif ($searchRow['approved'] == 'declined') {$thumbnail = 'declined';}
      else {$thumbnail = 'pending';}
      
      
      echo ''; 
          
      if (strlen(htmlentities($searchRow['name'])) >= 20) {$dot = '...';} else {$dot = '';}
      echo '<span style="display:inline-block;  width:100%">
        <a href="item?id=' . $searchRow['id'] . '"><img src="/shop_storage/thumbnails/'.$thumbnail.'.png?c=' . rand() . '" id="img" alt="" border="0" height="120" width="120">
<a id="AssetNameHyperLink" href="/shop/item/'. $searchRow['id'] .'">'. substr(htmlentities($searchRow['name']),0,17). '</a>        </span>
        <span style="display:inline-block; float:left; padding-left:0px;"><p class="shopDesc">by <a class="shopDesc" href="/user/'. $searchRow['owner_id'] . '">' . $userRow['username'] . '</a></p></span>
      <br> <br> <br><br>&nbsp;';
                               
      if ($searchRow['bucks'] == 0)
        {echo '<span class="offsale-text">Free</span>';}
      if ($searchRow['bits'] >= 1) {
        echo '<span class="bits-text"><span class="bits-icon"></span> '. $searchRow['bits'] .'            <img style="width:25px;vertical-align: middle;" src="/tixicon.png">
';}
      elseif ($searchRow['bits'] == 0 && $searchRow['bucks'] != 0)
        {echo '<span class="offsale-text">Free</span>';}
    elseif ($searchRow['bits'] == -1 && $searchRow['bucks'] != -1)
        {echo '<span class="offsale-text">Offsale</span>';}
    elseif ($searchRow['bucks'] == -1)
        {echo '<span class="offsale-text">Offsale</span>';}
      echo '</span></div>';
      
    //}
  }
  
  if(($items/36) > 1) {
    echo '<div>';
    for($i = 0; $i < ($items/36); $i++)
    {
      echo '<a style="color:#000;" onclick="getPage(\''.$item.'\',\''.$search.'\', '.$i.')">'.($i+1).'</a> ';
    }
    echo '</div>';
  }
  
  echo '</div>';
} else {
  echo 'Error loading crate';
  die();
}

?>
