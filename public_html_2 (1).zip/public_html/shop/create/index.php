<?php
include('../../webconfigs/config.php');
include('../../webconfigs/header.php');

if(!$loggedIn) {header('Location: ../'); die();}

?>

<!DOCTYPE html>
  <head>
    <title>Create - <?php echo $sitename; ?></title>
  </head>
  <div class="main-holder grid">
<div class="col-10-12 push-1-12">
</div>
<div class="col-10-12 push-1-12">
<div class="card">
<div class="content">
<div id="types" style="text-align:center;">

      
        <div style="display:inline-block;">
          <a style="font-weight:bold;font-size:18px;color:;margin:5px;" href="shirt"><img src="jbshirt.png"><br>Shirt</a>
        </div>
        <div style="display:inline-block;">
          <a style="font-weight:bold;font-size:18px;color:;margin:5px;" href="pants"><img src="jbpants.png"><br>Pants</a>
        </div>
  <?php
        if ($power >= 4) {
          ?>
                  <div style="display:inline-block;">
            <a style="font-weight:bold;font-size:18px;color:;margin:5px;" href="hat"><img src="head.png"><br>Hat</a>
          </div>
<div style="display:inline-block;">
            <a style="font-weight:bold;font-size:18px;color:;margin:5px;" href="face"><img src="head.png"><br>Face</a>
          </div>
   <div style="display:inline-block;">
            <a style="font-weight:bold;font-size:18px;color:;margin:5px;" href="tool"><img src="gear.png"><br>Tools</a>
          </div>
          <div style="display:inline-block;">
                </div>
    </div>
  </div>
  </div>
  </div>
      </div>
    </div>
  <?php
  }
    ?>
    </body>
</div>
  <?php include('../../webconfigs/footer.php'); ?>
  </body>
</html>