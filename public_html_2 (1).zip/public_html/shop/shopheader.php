
<div class="catalogcontainer">
    <h2>Sectorial Shop <a href="/shop/create"><button class="button">Create Clothing</button></a></h2>
 
    <h2>
               <a id="hat" onclick="getPage('hat','','0');">Hats</a>
<a id="hat" onclick="getPage('head','','0');">Heads</a>
<a id="hat" onclick="getPage('face','','0');">Faces</a>
            <a id="hat" onclick="getPage('tool','','0');">Gears</a>
<a id="hat" onclick="getPage('shirt','','0');">Shirts</a>
<a id="hat" onclick="getPage('pants','','0');">Pants</a>
 
         
  </h2>