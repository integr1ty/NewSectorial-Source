<?php
  include("webconfigs/config.php");
  include("webconfigs/head.php");

  if($loggedIn) {header("Location: /dashboard"); die();}
     
       ?>
<?php
$fetch_users = $conn->query("SELECT * FROM beta_users");
$total_users = mysqli_num_rows($fetch_users);



?>
<head>    
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $sitename; ?></title>
  </head>
<div class="container">
    <div class="loginform">
                   <center style="font-size: 9px;"><p>            <img style="width:70px;vertical-align: middle;" src="/SectLogo.png">
</p></center>

              <center style="font-size: 13px;"><p>Total Users: <?php echo $total_users ?></p></center>

                 <center style="font-size: 13px;"><p>Don't have an account? <a href="/register/">Sign up</a></p></center>

        </div>
  
    <div class="rightcontainer">
      <h1 style="margin-top: 0px;">
          Sectorial
      </h1>
      <ul id="Bullets">
        <li id="Bullet1">
          <h3>Build your personal Place</h3>
          <div>Create buildings, vehicles, scenery, and traps with thousands of virtual bricks.</div>
        </li>
        <li id="Bullet2">
          <h3>Meet new friends</h3>
          <div>Visit your friend's place, chat in 3D, and build together.</div>
        </li>
        <li id="Bullet3">
          <h3>Customize your character.</h3>
          <div>Adjust the look of your player, by buying hats from the catalog, uploading shirts, and changing the colors of your body parts!</div>
        </li>
        <div id="ctl00_cphGoodblox_pForParents" style="border: solid 1px #000; bottom: 10px; height: 150px; right: 10px; position: absolute; width: 150px;">
            <div id="ForParents">
                <a id="ctl00_cphRGoodblox_hlKidSafe" title="Sectorial is Summer-safe!" href="/" style="display:inline-block;"><img title="Sectorial is gamer-safe!" src="GamerSeal.png" border="0"></a>
            </div>
        </div>
      </ul>
      
    </div>
    
  </div>
   <div class="containergrey" style="margin-top: -160px;">
    Copyright © Sectorial 2024.<br><a href="https://discord.gg/8Gh5VP2GXb">            <img style="width:80px;vertical-align: middle;" src="disc.png"></a>
     
     <a href="https://twitter.com/vetatoriumm">            <img style="width:80px;vertical-align: middle;" src="twitter.png"></a>


  </div>

 