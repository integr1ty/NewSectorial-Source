<?php
  include("../webconfigs/configuration.php");
  include("adminheader.php");
 if($power < 1) {header("Location: ../");die();}
  ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin - <?php echo $sitename; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="row">
<div class="col-6 col-md-3 text-center">
<a href="manage-users" style="color:#28a745;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-user mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Users</div>
</div>
</div>
</a>
</div>
<div class="col-6 col-md-3 text-center">
<a href="manage-economy" style="color:#28a745;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fa fa-money mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Manage Economy</div>
</div>
</div>
</a>
</div>
<div class="col-6 col-md-3 text-center">
<a href="reports" style="color:#ffc107;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-flag mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Pending Reports</div>
</div>
  </div>
  </a>
  </div>
  <div class="col-6 col-md-3 text-center">
<a href="asset-approval" style="color:#ffc107;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-image mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Pending Assets</div>
</div>
</div>
</a>
</div>

    <div class="col-6 col-md-3 text-center">
<a href="site-settings" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-cog mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Site Settings</div>
</div>
</div>
</a>
</div>
    <div class="col-6 col-md-3 text-center">
<a href="givebuildersclub" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
            <img style="width:70px;vertical-align: middle;" src="/assets/membership/1.png">
<div class="text-truncate" style="font-weight:600;">Give Builders Club</div>
</div>
</div>
</a>
</div>
  
     <div class="col-6 col-md-3 text-center">
<a href="item" style="color:#38029;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-crown mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Give Item</div>
</div>
</div>
</a>
</div>
  
  <div class="col-6 col-md-3 text-center">
<a href="currency" style="color:#38029;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-coin mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Give Currency</div>
</div>
</div>
</a>
</div>
  
     <div class="col-6 col-md-3 text-center">
<a href="resetpassword" style="color:#38029;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-key mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Reset Password</div>
</div>
</div>
</a>
</div>
      <div class="col-6 col-md-3 text-center">
<a href="create/ad" style="color:#38029;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-ad mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create AD</div>
</div>
</div>
</a>
</div>
  
 
  </div>

 <footer class="container text-center mb-5 mt-5">
<div><strong> Sectorial: 2007R. 2024</strong></div>
<div class="text-muted" style="font-size:13px;"><strong>Admin Panel</strong></div>
</footer>
