<?php   include("../webconfigs/configuration.php");
include("adminheader.php");
  
$econSQL = "SELECT SUM(`bits`) AS 'totalBits' FROM `beta_users`";
$econQ = $conn->query($econSQL);
$econRow = $econQ->fetch_assoc();
$totalBits = $econRow['totalBits'];

$econSQL = "SELECT SUM(`bucks`) AS 'totalBucks' FROM `beta_users`";
$econQ = $conn->query($econSQL);
$econRow = $econQ->fetch_assoc();
$totalBucks = $econRow['totalBucks'];

$econ = $totalBits+($totalBucks*10);
  ?>
<title>Manage Economy - Sectorial</title>
<br>
<div class="catalogcontainer">

Total Economy             <img style="width:25px;vertical-align: middle;" src="/tixicon.png">
+             <img style="width:20px;vertical-align: middle;" src="/robux_icon.png">
 = (<?php echo $econ; ?>)
</div>