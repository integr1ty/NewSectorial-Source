<?php   include("../webconfigs/configuration.php");
include("adminheader.php");
     if($power < 1) {header("Location: ../");die(); }
  

  ?>
<title>Grant User - Sectorial</title>

