<footer class="container text-center mb-5 mt-5">
<div><strong>Copyright &copy; <?php echo $sitename; ?> 2024</strong></div>
<div class="text-muted" style="font-size:13px;"><strong>Admin Panel</strong></div>
</footer>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">