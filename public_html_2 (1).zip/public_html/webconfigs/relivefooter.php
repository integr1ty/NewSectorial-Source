<footer class="footer mt-auto py-3 bg-light">
<div class="container">
<p class="text-muted">This website is not affiliated, endorsed, and/or sponsored by any companies, trademarks, or copyrighted names mentioned. No copyright infringement is intended.</p>
<p class="text-muted mb-0">&copy; <?php echo $sitename; ?></p>
</div>
</footer>