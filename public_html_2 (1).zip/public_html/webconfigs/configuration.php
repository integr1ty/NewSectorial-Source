<?php
    
    
    include("config.php");
    
    
    $offline = true;
    $sitename = "Sectorial: 2007R";
    $sitelink = "https://sectorial.org";
    
?>


