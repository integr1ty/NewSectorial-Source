<?php 
//file_put_contents($_SERVER["DOCUMENT_ROOT"]."/SiT_3/connections.txt",$_SERVER['REMOTE_ADDR']."\n", FILE_APPEND | LOCK_EX);

     // die("Upgrading Server and fixing issues -Developers");

$conn = mysqli_connect( "mysql2.serv00.com" , "", "" , "");
  if(!$conn) {
    //include("site/maint.php");
    die("Database Error");
  }
  
  //sorry, but every page should require a session -lukey
  if(session_status() == PHP_SESSION_NONE) {
    session_name("BRICK-SESSION");
    session_start();
  }
?>