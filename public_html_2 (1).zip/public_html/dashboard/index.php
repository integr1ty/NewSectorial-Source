<?php
include('../webconfigs/head.php');

if ($loggedIn) {

  $currentUserID = $_SESSION['id'];
  $findUserSQL = "SELECT * FROM `beta_users` WHERE `id` = '$currentUserID'";
  $findUser = $conn->query($findUserSQL);
  
      //threads + posts = forum posts
            $postCountSQL = "SELECT * FROM `forum_posts` WHERE `author_id`='$currentUserID'"; //can't wait for php errors
            $postCount = $conn->query($postCountSQL);
            $posts = $postCount->num_rows;
            $threadCountSQL = "SELECT * FROM `forum_threads` WHERE `author_id`='$currentUserID'"; //wtf it worked, how?
          //can't believe it still works
            $threadCount = $conn->query($threadCountSQL);
            $threads = $threadCount->num_rows;
            
            $userPostCount = ($threads+$posts);

      //friends
$id = $userRow->{'id'};
$friendsQuery = "SELECT `from_id`,`to_id` FROM `friends` WHERE (`from_id`='$id' OR `to_id`='$id') AND `status`='accepted'";
$friends = $conn->query($friendsQuery);

$friendsArray = array();
while($friendRow = $friends->fetch_assoc()) {
  $friendsArray[] = $friendRow['from_id'];
  $friendsArray[] = $friendRow['to_id'];
}

$friendList = join("','",$friendsArray);
$friendnumrows = mysqli_num_rows($friends);

  if ($findUser->num_rows > 0) {
    $userRow = (object) $findUser->fetch_assoc();
  } else {
    unset($_SESSION['id']);
    header('Location: /');
    die();
  }
  
} else {
  header('Location: /');
  die();
}

//update desc
if (isset($_POST['desc'])) {
  $newDesc = mysqli_real_escape_string($conn,$_POST['desc']);
  //$newDesc = strip_tags($_POST['desc']);
  $userID = $userRow->{'id'};
  $updateDescSQL = "UPDATE `beta_users` SET `description` = '$newDesc' WHERE `id` = '$userID'";
  $updateDesc = $conn->query($updateDescSQL);
  header("Location: index");
  }
  //update status
if (isset($_POST['status'])) {
  //make something where you can't spam statuses
  $newStatus = mysqli_real_escape_string($conn,$_POST['status']);
  mysqli_query($conn,"INSERT INTO `statuses` VALUES (NULL,'$currentUserID','$newStatus','$curDate')");
  header("Location: index");
  }

$statusSQL = "SELECT * FROM `statuses` WHERE `owner_id`='$currentUserID' ORDER BY `id` DESC";
$findStatus = $conn->query($statusSQL);

if ($findStatus->num_rows > 0) {
  $statsRow = (object) $findStatus->fetch_assoc();
}
//games
$findGamesSQL = "SELECT * FROM `games`";
$findGames = $conn->query($findGamesSQL);
$gameRow = $findGames->fetch_assoc()

?>

<!DOCTYPE html>
<?php
  include("../webconfigs/alert.php");
  ?>

  <head>
    <title>Dashboard - <?php echo $sitename; ?></title>
  </head>
  <body>

</div>
 
  <div class="container profile">
    <div class="profile_left">
      <div class="user_pane">
        <span class="username"><font color="green">&#x25CF; </font> <?php echo $userRow->{'username'}; ?></span><br>
         <img class="img-responsive" style="display:inline;" src="/avatar/render/avatars/<?php echo $userRow->{'id'}; ?>.png?c=<?php echo $userRow->{'avatar_id'}; ?>">
        <div class="userpane_right">
          <p class="description"></p>
        </div>
        <br><br><br>
        <div class="badges_pane">
        <h4>User info</h4>

                <div class="content">
Friends: <?php echo $friendnumrows ?><br>
                  Posts: <?php echo $userPostCount ?><br>
                  Vists: 0<br>
         </div>


      </div>
    </div>

     </div>
     
    <div class="profile_right">
      <div class="friends_pane">
        <h4>Sectorial Socials</h4> 

                <div class="content">
              <a href="https://discord.gg/rsAAuJeCAn"><button class="button">Discord</button></a>
<a href="https://twitter.com/vetatoriumm"><button class="button">Twitter</button></a>
        </div>
      </div>
    </div>
    <div class="profile_right">
      <div class="friends_pane">
        <h4>Your Place</h4>

                <div class="content">
                  coming soon...
        </div>
      </div>
    </div>
 
 