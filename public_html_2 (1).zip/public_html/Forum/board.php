<?php
error_reporting(0);
  include("../webconfigs/header.php");
  
  $forumID = mysqli_real_escape_string($conn, intval($_GET['id']));
  
  if($power <= 0 && $forumID <= 0) {header("board?id=1");}
  
  if(isset($_GET['page'])) {$page = mysqli_real_escape_string($conn,intval($_GET['page']));} else {$page = 0;}
  $page = max($page,1);
  
  $sqlCount = "SELECT * FROM `forum_threads` WHERE `board_id` = '$forumID' AND `deleted` = 'no'";
  $countQ = $conn->query($sqlCount);
  $count = $countQ->num_rows;
  
  $page = min($page,max((int)($count/20),1));
  
  $limit = ($page-1)*20;
  $sqlPosts = "SELECT * FROM `forum_threads` WHERE  `board_id` = '$forumID' AND `deleted` = 'no' ORDER BY `pinned` ASC, `latest_post` DESC LIMIT $limit,20";
  $postsResult = $conn->query($sqlPosts);
    
  
  $BoardSQL = "SELECT * FROM `forum_boards` WHERE `id` = '$forumID'";
  $Board = $conn->query($BoardSQL);
  $BoardRow = $Board->fetch_assoc();
  $BoardName = $BoardRow['name'];
  
?>

<title> <?php echo $BoardName ?> - Sectorial</title>
  <meta charset="UTF-8">
  
<body>
  <div class="containergrey_nopadding">
          <h4 class="banner_title">All General Forums - <a href="/Forum/create?id=1/"><button class="button">Create</button></a>
</h4><br>
          <?php
            while($postRow=$postsResult->fetch_assoc()) {
              $postID = $postRow['id'];
              $authorID = $postRow['author_id'];
              
              $sqlAuthor = "SELECT * FROM `beta_users` WHERE `id`='$authorID'";
              $author = $conn->query($sqlAuthor);
              $authorRow = $author->fetch_assoc();
              
              $sqlReply = "SELECT * FROM `forum_posts` WHERE  `thread_id` = '$postID' ORDER BY `id` DESC";
              $replyResult = $conn->query($sqlReply);
              $replyRow=$replyResult->fetch_assoc();
              $replyNum=$replyResult->num_rows;
              $lastReplyID = $replyRow['author_id'];
              if (empty($lastReplyID)) {
                $sqlReply = "SELECT * FROM `forum_threads` WHERE  `id` = '$postID' ORDER BY `id` DESC";
                $replyResult = $conn->query($sqlReply);
                $replyRow=$replyResult->fetch_assoc();
                $lastReplyID = $replyRow['author_id'];
              }
              
              $sqlUser = "SELECT * FROM `beta_users` WHERE  `id` = '$lastReplyID'";
              $forumUserResult = $conn->query($sqlUser);
              $forumUserRow=$forumUserResult->fetch_assoc();
              
              $postViews = $postRow['views'] -1;
              echo '<tr class="forumColumn">
              <td>';
              
              if ($postRow['pinned'] == 'yes') {echo '<i class="fa fa-thumb-tack"></i> ';}
              if ($postRow['locked'] == 'yes') {echo '<i class="fa fa-lock"></i> ';}
              echo '<a class="title" href="thread?id=' . $postID .'">' . htmlentities($postRow['title']) . '</a><br><a style="font-size:12px;" href="/user?id='.$authorID.'">' . $authorRow['username'] . '</a>
              </td>
              <td style="text-align:center;">
                <p class="description">' . $replyNum . ' Replies</p>
              </td>
             
              <td>
                <p class="description"><strong>' . $replyRow['date'] . '</strong><br>by <a class="description" href="/user?id=' . $lastReplyID . '"><strong>' . $forumUserRow['username'] . '</strong></a></p>
              </td>
              </tr><hr>';
            }
          ?>
        </tbody>
      </table>
      <?php
      echo '</div><div class="numButtonsHolder" style="margin-left:auto;margin-right:auto;margin-top:10px;">';
      if($page-2 > 0) {
          echo '<a href="board?id='.$forumID.'&page=0">1</a> ... ';
      }
      if($count/20 > 1) {
              for($i = max($page-2,0); $i < min($count/20,$page+2); $i++)
              {
                echo '<a href="board?id='.$forumID.'&page='.($i+1).'">'.($i+1).'</a> ';
              }
            }
            if($count/20 > 4) {
                echo '... <a href="board?id='.$forumID.'&page='.(int)($count/20).'">'.(int)($count/20).'</a> ';
            }
      
      echo '</div>';
      ?>