<?php
  include("../webconfigs/config.php");
  include("../webconfigs/head.php");
  
  if(!$loggedIn) {header('Location: ../'); die();}
  
?>
<!DOCTYPE>
<html>

  <head>
    <title>Memebership - <?php echo $sitename; ?></title>
  </head>
 
<div class="catalogcontainer">
</h2><br>

  
  <center>
      <h3>We are not offering any virtual Purchases</h3>
     
     
    </center>
  
</div>